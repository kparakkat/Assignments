package com.mkyong.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mkyong.models.StockDAO;
import com.mkyong.models.StockManyDAO;
import com.mkyong.models.StudentDAO;

@Controller
@RequestMapping(value="/users")
public class ORMController {
	@Autowired
	private StockDAO _stockDao;
	
	@Autowired
	private StudentDAO _studentDao;
	
	@Autowired
	private StockManyDAO _stockManyDao;
	
	@Autowired
	PlatformTransactionManager transManager;
	TransactionStatus status = null;
	
	@RequestMapping(value="/saveonetoone")
	@ResponseBody
	public String createonetoone() {
	  try {
		  	TransactionDefinition def = new DefaultTransactionDefinition();
	        status = transManager.getTransaction(def);
	    	_stockDao.save();
	    	transManager.commit(status);
	  }
	  catch(Exception ex) {
		  transManager.rollback(status);
	      return ex.getMessage();
	  }
	  return "Stock succesfully saved!";
	}
	
	@RequestMapping(value="/saveonetomany")
	@ResponseBody
	public String createonetomany() {
	  try {
		  	TransactionDefinition def = new DefaultTransactionDefinition();
	        status = transManager.getTransaction(def);
	        _studentDao.save();
	    	transManager.commit(status);
	  }
	  catch(Exception ex) {
		  transManager.rollback(status);
	      return ex.getMessage();
	  }
	  return "Student succesfully saved!";
	}
	
	@RequestMapping(value="/savemanytomany")
	@ResponseBody
	public String createmanytomany() {
	  try {
		  	TransactionDefinition def = new DefaultTransactionDefinition();
	        status = transManager.getTransaction(def);
	        _stockManyDao.save();
	    	transManager.commit(status);
	  }
	  catch(Exception ex) {
		  transManager.rollback(status);
	      return ex.getMessage();
	  }
	  return "Category Stock succesfully saved!";
	}
}
