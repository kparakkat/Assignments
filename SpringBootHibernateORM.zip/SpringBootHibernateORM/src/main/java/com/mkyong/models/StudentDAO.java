package com.mkyong.models;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional(propagation=Propagation.REQUIRED)
public class StudentDAO {
	
	@Autowired
	private SessionFactory _sessionFactory;
	
	private Session getSession() {
	    return _sessionFactory.getCurrentSession();
	  }
	
	@Transactional(propagation=Propagation.MANDATORY)
	public void save() {
		Session session = getSession();
		Student studentObj = new Student("Java", "Geek",  "javageek@javacodegeeks.com", "0123456789");
		session.save(studentObj);

		MarksDetails marksObj1 = new MarksDetails("English", "100", "90",  "Pass");  
		marksObj1.setStudent(studentObj);  
		session.save(marksObj1);

		MarksDetails marksObj2 = new MarksDetails("Maths", "100", "99",  "Pass");  
		marksObj2.setStudent(studentObj);
		session.save(marksObj2);

		MarksDetails marksObj3 = new MarksDetails("Science", "100", "94",  "Pass");  
		marksObj3.setStudent(studentObj);
		session.save(marksObj3);
	}

}
