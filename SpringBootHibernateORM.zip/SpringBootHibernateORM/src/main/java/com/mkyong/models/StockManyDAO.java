package com.mkyong.models;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional(propagation=Propagation.REQUIRED)
public class StockManyDAO {
	
	@Autowired
	private SessionFactory _sessionFactory;
	
	private Session getSession() {
	    return _sessionFactory.getCurrentSession();
	  }
	
	@Transactional(propagation=Propagation.MANDATORY)
	public void save() {
		
		Session session = getSession();
		
		StockMany stock = new StockMany();
        stock.setStockCode("7052");
        stock.setStockName("PADINI");
 
        Category category1 = new Category("CONSUMER", "CONSUMER COMPANY");
        Category category2 = new Category("INVESTMENT", "INVESTMENT COMPANY");
    
        Set<Category> categories = new HashSet<Category>();
        categories.add(category1);
        categories.add(category2);
        
        stock.setCategories(categories);
        
        session.save(stock);
	}

}
