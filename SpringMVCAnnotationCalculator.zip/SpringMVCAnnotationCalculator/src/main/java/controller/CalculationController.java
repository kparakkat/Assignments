package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value="/calculator")
public class CalculationController {
	
	@RequestMapping(value="/add/{a}/{b}")
	String add(@PathVariable int a, @PathVariable int b, Model model){
		int c = a + b;
		String message = "Added Result " + c; 
		model.addAttribute("msg", message);
		return "result";
	}
	
	@RequestMapping(value="/sub", method= RequestMethod.GET)
	String subtract(@MatrixVariable(required=true, defaultValue="10") int a, @MatrixVariable(required=true, defaultValue="5") int b, Model model){
		int c = a - b;
		String message = "Subtract Result " + c; 
		model.addAttribute("msg", message);
		return "result";
	}
		
	@RequestMapping(value="/mult", method= RequestMethod.GET)
	String multiply(@RequestParam("a") int a, @RequestParam("b") int b, Model model){
		int c = a * b;
		String message = "Multiply Result " + c; 
		model.addAttribute("msg", message);
		return "result";
	}

}
