package controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Calculator{
	@GetMapping(value="/add/{num1}/{num2}")
	public String add(@PathVariable("num1") int num1, @PathVariable("num2") int num2){
	   return "" + (num1+num2);
	}
 
	@GetMapping(value="/sub")
	public String subtract(@MatrixVariable(required=true, defaultValue="10") int num1, @MatrixVariable(required=true, defaultValue="5") int num2){
		return "" + (num1-num2);
	}
		
	@GetMapping(value="/mult")
	String multiply(@RequestParam("num1") int num1, @RequestParam("num2") int num2){
		return "" + (num1*num2);
	}
}
