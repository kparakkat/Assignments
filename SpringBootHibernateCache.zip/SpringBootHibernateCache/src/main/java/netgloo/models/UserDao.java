package netgloo.models;

import java.util.List;

//import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional//(propagation=Propagation.MANDATORY)
public class UserDao {
  
  @Autowired
  private SessionFactory _sessionFactory;
  
  private Session getSession() {
    return _sessionFactory.getCurrentSession();
  }
  
  private Session getOpenSession() {
	    return _sessionFactory.openSession();
	  }

  public void save(User user) {
    getSession().save(user);
    return;
  }
  
  public void delete(User user) {
    getSession().delete(user);
    return;
  }
  
  @SuppressWarnings("unchecked")
  public List<User> getAll() {
    return getSession().createQuery("from User").list();
  }
  
  public User getByEmail(String email) {
    return (User) getSession().createQuery(
        "from User where email = :email")
        .setParameter("email", email)
        .uniqueResult();
  }

  public User getById(long id) {
    return (User) getSession().load(User.class, id);
  }

  public void update(User user) {
    getSession().update(user);
    return;
  }
  
  public void loadFromEhCache()
  {
	  	Session session1 = getOpenSession();		
		Object o=session1.load(User.class,new Long(1));
		
		User s=(User)o;
		System.out.println("Loaded object user name is___"+s.getName());		
		System.out.println("Object Loaded successfully.....!!");	
		session1.close(); 
		
		System.out.println("------------------------------");
		System.out.println("Waiting......");
		
		try{ 
			Thread.sleep(6000);
		}
		catch (Exception e) {
		}		
		
		System.out.println("6 seconds compelted......!!!!!!!!");
		
		Session session2 = getOpenSession();		
		Object o2=session2.load(User.class,new Long(1)); 
		
		User s2=(User)o2;
		System.out.println("Loaded object user name is___"+s2.getName());		
		System.out.println("Object loaded from the database...!!");	
		session2.close();
		
		
		Session session3 = getOpenSession();		
		Object o3=session3.load(User.class,new Long(1));
		
		User s3=(User)o3;
		System.out.println("Loaded object user name is___"+s3.getName());		
		System.out.println("Object loaded from global cache successfully.....!!");	
		session3.close();
  }

} // class UserDao
