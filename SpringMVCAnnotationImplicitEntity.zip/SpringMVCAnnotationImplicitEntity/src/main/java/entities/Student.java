package entities;

public class Student {
	private int idno;
	private String name;
	private int age;
        
    public void setAge(int age) {
   	  this.age = age;
    }
    
    public void setName(String name) {
  	  this.name = name;
   }
    
    public void setidno(int idno) {
  	  this.idno = idno;
   }
    
    public int getAge() {
  	  return age;
   }
    
   public String getName() {
     	  return name;
      }
    
    public int getidno() {
    	  return idno;
     }
    
}
