package com.entities;

public class Employee
{
	int empid;
	String firstName;
	String lastName;
	String email;
	
	public Employee() {}
	
	public Employee(int id, String fname, String lname, String em)
	{
		empid = id;
		firstName = fname;
		lastName = lname;
		email = em;
	}
	
	public int getempid()
	{
		return empid;
	}
	
	public void setempid(int eid)
	{
		empid = eid;
	}
	
	public String getfirstName()
	{
		return firstName;
	}
	
	public void setfirstName(String fname)
	{
		firstName = fname;
	}
	
	public String getlastName()
	{
		return firstName;
	}
	
	public void setlastName(String lname)
	{
		lastName = lname;
	}
	
	public String getemail()
	{
		return email;
	}
	
	public void setemail(String em)
	{
		email = em;
	}
}


