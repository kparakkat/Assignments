package com.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

import com.entities.Employee;

@Service
public class EmployeeService{
	ArrayList<Employee> emplist;

	public EmployeeService() {
		emplist = new ArrayList<Employee>();
		Employee empOne = new Employee(1,"Lok", "Gupta", "lk@gmail.com");
		this.emplist.add(empOne);
	}

	public Employee getEmployee(int empid)
	{
		Employee employee = null;
		for(Employee emp:emplist)
		{
		  if(emp.getempid() == empid) 
		  {
			  employee=emp;
			  break;
		  } //if
		} //for
		return employee;
	}
	
	public List<Employee> getAllEmployees(){
		return this.emplist;
		}
	
	public void addEmployee(Employee employee){

		this.emplist.add(employee);
		}


}

